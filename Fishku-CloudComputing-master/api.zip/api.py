import os 
import numpy as np
import requests
from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import load_img, img_to_array

app = Flask(__name__)
model = load_model('my_model.h5')

@app.route('/prediction', methods=['POST'])
def fish_prediction():
    # check photo uploded
    if 'photo_uri' not in request.files:
        return jsonify({'error': 'No image uploaded.'}), 400
    url = request.files.get('photo_url')
    if not url:
        return

    # save photo that want to predict
    temp_file = f'images/{url.filename}'
    url.save(temp_file)

    # begin prediction
    img = load_img(temp_file, target_size=(150, 150))
    x = img_to_array(img)
    x = np.expand_dims(x, axis=0)
    images = np.vstack([x])
    classes = model.predict(images, batch_size=10)
    if np.argmax(classes) == 0:
        fish_name = "Gurame"
    elif np.argmax(classes) == 1:
        fish_name = "Lele"
    elif np.argmax(classes) == 2:
        fish_name = "Tongkol"
    else:
        fish_name = "Unclassified"
    
    os.remove(temp_file)
    return jsonify({'fish_name' : fish_name})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))